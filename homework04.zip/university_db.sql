-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 04, 2026 lúc 08:33 AM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.2.12

/*
Student name: Lê Thu Phương 
Student ID: 23070512
Assignment: INS3064 - Homework 4 - University Database
Date: 2026-10-04
*/

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `university_db`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `courses`
--

CREATE TABLE `courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `course_name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `credits` int(10) UNSIGNED NOT NULL DEFAULT 3,
  `department_id` int(10) UNSIGNED NOT NULL,
  `instructor_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ;

--
-- Đang đổ dữ liệu cho bảng `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_name`, `description`, `credits`, `department_id`, `instructor_id`, `created_at`) VALUES
(1, 'INS3064', 'Web Development', 'Web application development using PHP and MySQL.', 3, 1, 1, '2026-10-04 13:32:30'),
(2, 'CS101', 'Introduction to Programming', 'Programming fundamentals and problem solving.', 3, 2, 2, '2026-10-04 13:32:30'),
(3, 'BA201', 'Principles of Management', 'Planning, organizing, leading, and controlling.', 3, 3, 3, '2026-10-04 13:32:30'),
(4, 'ACC101', 'Financial Accounting', 'Basic accounting principles and financial statements.', 3, 4, 4, '2026-10-04 13:32:30'),
(5, 'ENG201', 'Business English', 'English communication in professional settings.', 2, 5, 5, '2026-10-04 13:32:30');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `departments`
--

CREATE TABLE `departments` (
  `id` int(10) UNSIGNED NOT NULL,
  `department_code` varchar(10) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `departments`
--

INSERT INTO `departments` (`id`, `department_code`, `department_name`, `description`, `created_at`) VALUES
(1, 'MIS', 'Management Information Systems', 'Information systems for business and management.', '2026-10-04 13:32:30'),
(2, 'CS', 'Computer Science', 'Programming, algorithms, and computing.', '2026-10-04 13:32:30'),
(3, 'BA', 'Business Administration', 'Business management and organizational studies.', '2026-10-04 13:32:30'),
(4, 'ACC', 'Accounting', 'Financial accounting and reporting.', '2026-10-04 13:32:30'),
(5, 'ENG', 'English Language', 'English language and professional communication.', '2026-10-04 13:32:30');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `enrollments`
--

CREATE TABLE `enrollments` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(10) UNSIGNED NOT NULL,
  `course_id` int(10) UNSIGNED NOT NULL,
  `semester_id` int(10) UNSIGNED NOT NULL,
  `enrollment_date` date NOT NULL,
  `grade` decimal(3,2) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ;

--
-- Đang đổ dữ liệu cho bảng `enrollments`
--

INSERT INTO `enrollments` (`id`, `student_id`, `course_id`, `semester_id`, `enrollment_date`, `grade`, `created_at`) VALUES
(1, 1, 1, 1, '2024-09-02', 3.00, '2026-10-04 13:32:30'),
(2, 2, 2, 1, '2024-09-03', 3.70, '2026-10-04 13:32:30'),
(3, 3, 3, 1, '2024-09-04', 2.70, '2026-10-04 13:32:30'),
(4, 4, 4, 2, '2025-01-16', 3.50, '2026-10-04 13:32:30'),
(5, 5, 5, 2, '2025-01-17', 4.00, '2026-10-04 13:32:30'),
(6, 1, 5, 2, '2025-01-18', 3.30, '2026-10-04 13:32:30'),
(7, 2, 1, 3, '2025-09-02', 3.70, '2026-10-04 13:32:30'),
(8, 3, 4, 3, '2025-09-03', 3.00, '2026-10-04 13:32:30'),
(9, 4, 3, 3, '2025-09-04', 3.30, '2026-10-04 13:32:30'),
(10, 5, 1, 4, '2026-01-16', 3.70, '2026-10-04 13:32:30'),
(11, 1, 2, 4, '2026-01-17', 3.30, '2026-10-04 13:32:30'),
(12, 2, 5, 4, '2026-01-18', 4.00, '2026-10-04 13:32:30'),
(13, 3, 1, 5, '2026-09-02', NULL, '2026-10-04 13:32:30'),
(14, 4, 4, 5, '2026-09-03', NULL, '2026-10-04 13:32:30'),
(15, 5, 5, 5, '2026-09-04', NULL, '2026-10-04 13:32:30');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `instructors`
--

CREATE TABLE `instructors` (
  `id` int(10) UNSIGNED NOT NULL,
  `instructor_code` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `gender` enum('male','female','other') NOT NULL DEFAULT 'other',
  `department_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `instructors`
--

INSERT INTO `instructors` (`id`, `instructor_code`, `full_name`, `email`, `phone`, `gender`, `department_id`, `created_at`) VALUES
(1, 'GV001', 'Nguyễn Văn Minh', 'minh.nguyen@example.com', '0901000001', 'male', 1, '2026-10-04 13:32:30'),
(2, 'GV002', 'Trần Thị Lan', 'lan.tran@example.com', '0901000002', 'female', 2, '2026-10-04 13:32:30'),
(3, 'GV003', 'Lê Quốc Hùng', 'hung.le@example.com', '0901000003', 'male', 3, '2026-10-04 13:32:30'),
(4, 'GV004', 'Phạm Thu Hà', 'ha.pham@example.com', '0901000004', 'female', 4, '2026-10-04 13:32:30'),
(5, 'GV005', 'Hoàng Ngọc Anh', 'anh.hoang@example.com', '0901000005', 'female', 5, '2026-10-04 13:32:30');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `semesters`
--

CREATE TABLE `semesters` (
  `id` int(10) UNSIGNED NOT NULL,
  `semester_code` varchar(20) NOT NULL,
  `semester_name` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ;

--
-- Đang đổ dữ liệu cho bảng `semesters`
--

INSERT INTO `semesters` (`id`, `semester_code`, `semester_name`, `start_date`, `end_date`, `created_at`) VALUES
(1, 'FALL2024', 'Fall 2024', '2024-09-01', '2024-12-31', '2026-10-04 13:32:30'),
(2, 'SPRING2025', 'Spring 2025', '2025-01-15', '2025-05-31', '2026-10-04 13:32:30'),
(3, 'FALL2025', 'Fall 2025', '2025-09-01', '2025-12-31', '2026-10-04 13:32:30'),
(4, 'SPRING2026', 'Spring 2026', '2026-01-15', '2026-05-31', '2026-10-04 13:32:30'),
(5, 'FALL2026', 'Fall 2026', '2026-09-01', '2026-12-31', '2026-10-04 13:32:30');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_code` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `gender` enum('male','female','other') NOT NULL DEFAULT 'other',
  `date_of_birth` date NOT NULL,
  `gpa` decimal(3,2) DEFAULT NULL,
  `department_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ;

--
-- Đang đổ dữ liệu cho bảng `students`
--

INSERT INTO `students` (`id`, `student_code`, `full_name`, `email`, `phone`, `gender`, `date_of_birth`, `gpa`, `department_id`, `created_at`) VALUES
(1, 'SV001', 'Nguyễn Văn An', 'an.nguyen@example.com', '0912000001', 'male', '2004-03-15', 3.20, 1, '2026-10-04 13:32:30'),
(2, 'SV002', 'Trần Thu Trang', 'trang.tran@example.com', '0912000002', 'female', '2004-07-20', 3.60, 2, '2026-10-04 13:32:30'),
(3, 'SV003', 'Lê Minh Đức', 'duc.le@example.com', '0912000003', 'male', '2003-11-05', 2.80, 3, '2026-10-04 13:32:30'),
(4, 'SV004', 'Phạm Hồng Anh', 'honganh.pham@example.com', '0912000004', 'female', '2004-01-12', 3.45, 4, '2026-10-04 13:32:30'),
(5, 'SV005', 'Hoàng Mai Linh', 'linh.hoang@example.com', '0912000005', 'female', '2004-09-08', 3.75, 5, '2026-10-04 13:32:30');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_courses_code` (`course_code`),
  ADD KEY `fk_courses_department` (`department_id`),
  ADD KEY `fk_courses_instructor` (`instructor_id`);

--
-- Chỉ mục cho bảng `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_departments_code` (`department_code`),
  ADD UNIQUE KEY `uq_departments_name` (`department_name`);

--
-- Chỉ mục cho bảng `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_enrollments_student_course_semester` (`student_id`,`course_id`,`semester_id`),
  ADD KEY `fk_enrollments_course` (`course_id`),
  ADD KEY `fk_enrollments_semester` (`semester_id`);

--
-- Chỉ mục cho bảng `instructors`
--
ALTER TABLE `instructors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_instructors_code` (`instructor_code`),
  ADD UNIQUE KEY `uq_instructors_email` (`email`),
  ADD KEY `fk_instructors_department` (`department_id`);

--
-- Chỉ mục cho bảng `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_semesters_code` (`semester_code`),
  ADD UNIQUE KEY `uq_semesters_name` (`semester_name`);

--
-- Chỉ mục cho bảng `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_students_code` (`student_code`),
  ADD UNIQUE KEY `uq_students_email` (`email`),
  ADD KEY `fk_students_department` (`department_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `instructors`
--
ALTER TABLE `instructors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `semesters`
--
ALTER TABLE `semesters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `students`
--
ALTER TABLE `students`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `fk_courses_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_courses_instructor` FOREIGN KEY (`instructor_id`) REFERENCES `instructors` (`id`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `fk_enrollments_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_enrollments_semester` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_enrollments_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `instructors`
--
ALTER TABLE `instructors`
  ADD CONSTRAINT `fk_instructors_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE;

--
-- Các ràng buộc cho bảng `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_students_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
